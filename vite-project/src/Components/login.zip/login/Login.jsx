import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Login.css";

const Login = () => {
  return (
    <div className="login-container d-flex justify-content-center align-items-center">
      <div className="card shadow p-4" style={{ width: "350px" }}>
        <h4 className="text-center mb-4">Login</h4>
        <form>
          {/* Admin Field */}
          <div className="mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Admin *"
              required
            />
          </div>

          {/* Password Field */}
          <div className="mb-3">
            <input
              type="password"
              className="form-control"
              placeholder="Password *"
              required
            />
          </div>

          {/* Token Field */}
          <div className="mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Token *"
              required
            />
          </div>

          {/* Login Button */}
          <div className="d-grid">
            <button type="submit" className="btn btn-primary">
              LOGIN
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
